from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model

class MultiFieldModelBackend(ModelBackend):
    def authenticate(self, request, username=None, password=None, **kwargs):
        User = get_user_model()
        user = None

        # Try finding user by email, mobile, or username
        if User.objects.filter(email=username).exists():
            user = User.objects.get(email=username)
        elif User.objects.filter(mobile=username).exists():
            user = User.objects.get(mobile=username)
        elif User.objects.filter(username=username).exists():
            user = User.objects.get(username=username)

        # Check if user exists and is active
        if user and user.check_password(password) and self.user_can_authenticate(user):
            return user

        return None  # Return None if authentication fails
