from django.urls import path
from . import views

app_name = 'CustomLogin'

urlpatterns = [
    path('signup', views.RegisterView.as_view(), name='signup'),
    path('signin',views.CustomLoginView.as_view(), name='signin'),
    path('greetings',views.greetings, name='greetings'),
]
