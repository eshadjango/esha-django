from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import AuthenticationForm
from django.core.exceptions import ValidationError
from .models import CustomUser  # Assuming you have CustomUser model

User = get_user_model()  # This ensures we're using the correct user model

# Registration Form
class RegistrationForm(forms.ModelForm):
    password1 = forms.CharField(label='Password', widget=forms.PasswordInput)
    password2 = forms.CharField(label='Confirm Password', widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'full_name', 'email', 'mobile']
        widgets = {
            'full_name': forms.TextInput(attrs={'autofocus': True})
        }

    def clean(self):
        cleaned_data = super().clean()
        email = cleaned_data.get('email')
        phone = cleaned_data.get('mobile')
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')

        # Ensure either email or mobile is provided
        if not email and not phone:
            raise forms.ValidationError("Please provide an email or mobile number.")

        # Ensure that passwords match
        if password1 != password2:
            raise forms.ValidationError("Passwords do not match.")

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])

        # Activate the user if they were inactive
        if not user.is_active:
            user.is_active = True  # Set active status to True

        if commit:
            user.save()
        return user


# Custom Authentication Form (for login)
class CustomAuthenticationForm(AuthenticationForm):
    username = forms.CharField(label="Username or Email")

    def clean_username(self):
        username_or_email = self.cleaned_data.get("username")

        # Try to fetch user by email if the input matches an email
        try:
            user = User.objects.get(email=username_or_email)
            return user.username  # Return the username for authentication
        except User.DoesNotExist:
            # If no user found by email, return the input as username
            return username_or_email

    def clean(self):
        cleaned_data = super().clean()
        username = cleaned_data.get("username")

        # Ensure that the username is provided
        if not username:
            raise ValidationError("This field cannot be blank.")

        # Check if the user exists and is inactive
        try:
            user = User.objects.get(username=username)
            if not user.is_active:
                user.is_active = True  # Automatically activate the user
                user.save()
        except User.DoesNotExist:
            pass  # Let Django's default authentication handle invalid credentials

        return cleaned_data
