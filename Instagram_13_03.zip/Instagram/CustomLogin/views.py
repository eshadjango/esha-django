from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views.generic.edit import CreateView, FormView
from django.contrib.auth import login, authenticate, get_user_model
from django.contrib.auth.models import User  # Make sure this is imported
from .forms import RegistrationForm, CustomAuthenticationForm
from .models import CustomUser

User = CustomUser()  # This ensures you get your CustomUser model


class RegisterView(CreateView):
    form_class = RegistrationForm
    template_name = 'CustomLogin/signup.html'
    success_url = reverse_lazy('CustomLogin:signin')  # Ensure signin URL is correct!

    def form_valid(self, form):
        print(" Form is valid. Redirecting to signin.")  # Debugging
        response = super(RegisterView, self).form_valid(form)
        return response  # This should trigger the redirect

    def form_invalid(self, form):
        print(" Form is invalid. Errors:", form.errors)  # Debugging
        return self.render_to_response(self.get_context_data(form=form))

class CustomLoginView(FormView):
    template_name = 'CustomLogin/signin.html'
    form_class = CustomAuthenticationForm
    success_url = reverse_lazy('CustomLogin:greetings')  # Redirect after login

    def form_valid(self, form):
        username_or_email = form.cleaned_data.get('username')  # Can be email/username
        password = form.cleaned_data.get('password')

        print(f'Username/Email entered: {username_or_email}')
        print(f'Password entered: {password}')

        user = authenticate(self.request, username=username_or_email, password=password)

        if user:
            print("Authentication Successful! Logging in...")
            login(self.request, user)
            return redirect(self.get_success_url())  # Redirect to greetings page
        else:
            print("Authentication Failed! Invalid username/email or password")
            form.add_error(None, "Invalid username/email or password")
            return self.form_invalid(form)


def greetings(request):
    return render(request, 'CustomLogin/greeting.html', {'user': request.user})
