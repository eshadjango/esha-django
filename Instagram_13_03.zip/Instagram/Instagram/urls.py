from django.contrib import admin
from django.urls import path, include



urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/',include('accounts.urls')),
    path('CRUD/',include('CRUD.urls') ),
    path('newsfeed/',include('newsfeed.urls')),
    path('Authy/',include('Authy.urls',namespace='Authy')),
    path('Password_Task/',include('Password_Task.urls',namespace='Password_Task')),
    path('CustomLogin/',include('CustomLogin.urls',namespace='CustomLogin')),






]
