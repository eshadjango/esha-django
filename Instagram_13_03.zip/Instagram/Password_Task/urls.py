
from django.urls import path
from . import views  # Import views from the current app

app_name = 'Password_Task'
urlpatterns = [

    path('registration/', views.registration, name="registration"),
    path('login_view/', views.login_view, name="login_view"),
    path('login_successful/', views.login_successful, name="login_successful"),
    path('password_reset_confirm/<uidb64>/<token>/', views.password_reset_confirm, name="password_reset_confirm"),
    path('password_reset_form/', views.password_reset_form, name="password_reset_form"),
    path('login_view/', views.login_view, name="login_view"),
    path('login_successful/', views.login_successful, name="login_successful"),
    path('password_reset_request/', views.password_reset_request, name="password_reset_request"),
    path('password_reset_done/', views.password_reset_done, name="password_reset_done"),





]
