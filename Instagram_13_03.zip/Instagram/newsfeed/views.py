from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required(login_url='accounts:signin')
def home(request):
    return render(request, "newsfeed/home.html")  # Update template path

@login_required(login_url='accounts:signin')
def activity(request):
    return render(request, "newsfeed/Activity.html")

