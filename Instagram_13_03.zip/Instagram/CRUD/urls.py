from django.contrib import admin
from django.urls import path
from . import views  # Import views from the current app

urlpatterns = [
    path('admin/', admin.site.urls),
    path('create_user/', views.creation_user, name="create_user"),
    path('read_user/', views.reading_user, name="read_user"),
    path('update_user/<str:username>', views.updating_user, name="update_user"),
    path('delete_user/<int:id>', views.deleting_user, name="delete_user"),
    path('list_user/', views.list_user, name="list_user"),
]
