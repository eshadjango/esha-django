from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.contrib.sites.shortcuts import get_current_site
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.contrib import messages
from .models import CustomUser
from .forms import CustomUserForms
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.forms import AuthenticationForm
from django.utils.html import strip_tags

def registration(request):
    print("Registration view triggered")  # Debugging

    if request.method == 'POST':
        print("POST request received")  # Debugging

        form = CustomUserForms(request.POST, request.FILES)
        print("Form initialized with POST data")  # Debugging

        if form.is_valid():
            print("Form is valid")  # Debugging
            # Extracting form data
            username = form.cleaned_data['username']
            full_name = form.cleaned_data['full_name']
            email = form.cleaned_data['email']
            mobile = form.cleaned_data['mobile']
            password = form.cleaned_data['password']
            password_confirmation = form.cleaned_data['password_confirmation']

            print(f"User Data - Username: {username}, Full Name: {full_name}, Email: {email}, Mobile: {mobile}")  # Debugging
            user = CustomUser.objects.filter(username=username).first()

            # Check if username, email, or mobile already exists
            if CustomUser.objects.filter(username=username).exists():
                print(f"Username {username} already exists")  # Debugging
                return render(request, 'Authy/register.html', {'form': form, 'error': 'Username already exists'})
            if CustomUser.objects.filter(email=email).exists():
                print(f"Email {email} already exists")  # Debugging
                return render(request, 'Authy/register.html', {'form': form, 'error': 'Email already exists'})
            if CustomUser.objects.filter(mobile=mobile).exists():
                print(f"Mobile {mobile} already exists")  # Debugging
                return render(request, 'Authy/register.html', {'form': form, 'error': 'Mobile already exists'})

            # Validate passwords match
            if password != password_confirmation:
                print("Passwords do not match")  # Debugging
                return render(request, 'Authy/register.html', {'form': form, 'error': 'Passwords do not match'})

            # Create the user with is_active=False to prevent login until email is verified
            print("Creating the user with is_active=False")  # Debugging
            user = CustomUser.objects.create_user(
                username=username,
                full_name=full_name,
                email=email,
                mobile=mobile,
                password=password,  # Django hashes the password automatically
                is_active=False,  # User is inactive until email is verified
            )
            print(f"User {user.username} created successfully!")  # Debugging
def login_view(request):
    print(" Login view triggered")  # Debugging

    if request.method == 'POST':
        print("POST request received")  # Debugging

        form = AuthenticationForm(request, data=request.POST)
        print(" Form initialized with POST data")  # Debugging

        if form.is_valid():
            print(" Form is valid")  # Debugging

            # Extract username and password
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')

            print(f" Extracted Username: {username}, Password: {password}")  # Debugging

            # Authenticate user
            user = authenticate(request, username=username, password=password)

            if user is not None:
                print(f"User authenticated: {user.username}")
                login(request, user)
                messages.success(request, 'You have logged in successfully!')
                return redirect('Authy:login_successful')  # Redirect to success page
            else:
                print(" Authentication failed: Incorrect credentials or user does not exist.")
                messages.error(request, ' Invalid username or password.')
        else:
            print("Form errors:", form.errors)  # Debugging: Check form validation errors
            messages.error(request, 'Invalid form submission.')

    else:
        form = AuthenticationForm()
        print(" GET request received, rendering login form.")  # Debugging

    return render(request, 'Authy/login_view.html', {'form': form})
