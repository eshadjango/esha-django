from Authy.forms import CustomUserForms


class ExtendedUser(CustomUserForms):
    class Meta(CustomUserForms.Meta):
        fields = '__all__'
