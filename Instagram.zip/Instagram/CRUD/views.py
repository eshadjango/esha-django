from django.shortcuts import render, redirect
from .models import CustomUser
from django.db.utils import IntegrityError

def creation_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        bio = request.POST['bio']

        if CustomUser.objects.filter(username=username).exists():
            return render(request, 'CRUD/read_user.html', {'error': 'Username already exists'})

        if CustomUser.objects.filter(email=email).exists():
            return render(request, 'CRUD/list_user.html', {'error': 'Email already exists'})

        CustomUser.objects.create(username=username, email=email, bio=bio)
        return redirect('list_user')

    return render(request, 'CRUD/create_user.html')

def reading_user(request):
    users = CustomUser.objects.all()
    if users.exists():
        return render(request, 'CRUD/read_user.html', {'users': users})
    return render(request, 'CRUD/read_user.html', {'error': 'No users found'})

def updating_user(request,username):
    user = CustomUser.objects.filter(username=username).first()
    if not user:
        return render(request,'CRUD/update_user.html',{'error':'The user does not exists!'})

    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        bio = request.POST['bio']


        # if CustomUser.objects.filter(username=username).exists():
        #     return render(request, 'CRUD/update_user.html',{'error':'The user already exists!'})
        # if CustomUser.objects.filter(email=email).exists():
        #     return render(request, 'CRUD/update_user.html', {'error': 'Email already exists'})
        try:
            user.username = username
            user.email = email
            user.bio = bio
            user.save()
        except IntegrityError:
            if CustomUser.objects.filter(username=username).exclude(id=user.id).exists():
                return render(request, 'CRUD/update_user.html',{'user':user,'error':'The user already exists!'})

            if CustomUser.objects.filter(email=email).exclude(id=user.id).exists():
                return render(request, 'CRUD/update_user.html', {'user':user,'error': 'Email already exists'})




        return redirect('list_user')
    return render(request,'CRUD/update_user.html',{'user':user})

def deleting_user(request,id):
    # if request.method == 'POST':
        # username = request.POST['username']

    if CustomUser.objects.filter(id=id).exists():
        CustomUser.objects.get(id=id).delete()
        return redirect('list_user')

    return render(request, 'CRUD/delete_user.html', {'error': 'User not found!!'})

    # return render(request, 'CRUD/delete_user.html')

def list_user(request):
    users = CustomUser.objects.all()

    return render(request, 'CRUD/list_user.html', {'users': users})
