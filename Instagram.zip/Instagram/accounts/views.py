from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login


def signup(request):
    # request_data = request.scheme
    # print(request_data)
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(first_name)
        print(username)


        if User.objects.filter(username=username):
            return render(request, 'accounts/signup.html')

        User.objects.create_user(
            first_name=first_name,
            username=username,
            password=password
        )
        return redirect('signin')
    return render(request, 'accounts/signup.html')



def signin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request,username=username,password=password)
        print(user)

        if user is not None:
            login(request,user)
            return redirect('accounts:greeting')
        else:
            return render(request, 'accounts/signin.html', {'error': 'Invalid username or password'})
    return render(request, 'accounts/signin.html')

def greeting(request):
    return render(request, 'accounts/greeting.html', {'user':request.user})
