
from django.urls import path
from accounts import views

app_name = 'accounts'

urlpatterns = [
    path('signup/', views.signup, name= "signup"),
    path('signin/',views.signin,name= "signin"),
    path('greeting/',views.greeting,name= "greeting"),


    # path('logout/',views.logout,name= "logout"),
    # path('changepassword/',views.changepassword,name= "changepassword"),

]
