from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class Registration(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

    #Registration:Registration object(2) change it to Registration:Registration object(username)
    def __str__(self):
        return f"Registration object ({self.username})"

class CustomerUserManager(BaseUserManager):
    def create_user(self, username, email=None, mobile=None, password = None, **extra_fields):
        if not username:
            raise ValueError("The username field must be set")

        email = self.normalize_email(email) if email else None
        user = self.model( username = username, email = email, mobile = mobile, **extra_fields)
        user.set_password(password)
        user.save()
        return user




class CustomUser(AbstractBaseUser):
    username = models.CharField(max_length=50, unique=True)
    full_name = models.CharField(max_length=150)
    email= models.EmailField(unique= True, blank=True, null= True)
    mobile = models.CharField(max_length=15,unique= True, blank=True, null= True)
    bio = models.TextField(max_length=1500, blank=True)
    profile_picture = models.ImageField(upload_to='profiles/',blank=True, null= True)

    objects = CustomerUserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['full_name']

    def __str__(self):
        return self.username



