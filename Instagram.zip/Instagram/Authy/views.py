from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.contrib.sites.shortcuts import get_current_site
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.contrib import messages
from .models import CustomUser
from .forms import CustomUserForms
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.forms import AuthenticationForm
from django.utils.html import strip_tags


def registration(request):
    print("Registration view triggered")  # Debugging

    if request.method == 'POST':
        print("POST request received")  # Debugging

        form = CustomUserForms(request.POST, request.FILES)
        print("Form initialized with POST data")  # Debugging

        if form.is_valid():
            print("Form is valid")  # Debugging
            # Extracting form data
            username = form.cleaned_data['username']
            full_name = form.cleaned_data['full_name']
            email = form.cleaned_data['email']
            mobile = form.cleaned_data['mobile']
            password = form.cleaned_data['password']
            password_confirmation = form.cleaned_data['password_confirmation']

            print(f"User Data - Username: {username}, Full Name: {full_name}, Email: {email}, Mobile: {mobile}")  # Debugging
            user = CustomUser.objects.filter(username=username).first()

            # Check if username, email, or mobile already exists
            if CustomUser.objects.filter(username=username).exists():
                print(f"Username {username} already exists")  # Debugging
                return render(request, 'Authy/register.html', {'form': form, 'error': 'Username already exists'})
            if CustomUser.objects.filter(email=email).exists():
                print(f"Email {email} already exists")  # Debugging
                return render(request, 'Authy/register.html', {'form': form, 'error': 'Email already exists'})
            if CustomUser.objects.filter(mobile=mobile).exists():
                print(f"Mobile {mobile} already exists")  # Debugging
                return render(request, 'Authy/register.html', {'form': form, 'error': 'Mobile already exists'})

            # Validate passwords match
            if password != password_confirmation:
                print("Passwords do not match")  # Debugging
                return render(request, 'Authy/register.html', {'form': form, 'error': 'Passwords do not match'})

            # Create the user with is_active=False to prevent login until email is verified
            print("Creating the user with is_active=False")  # Debugging
            user = CustomUser.objects.create_user(
                username=username,
                full_name=full_name,
                email=email,
                mobile=mobile,
                password=password,  # Django hashes the password automatically
                is_active=False,  # User is inactive until email is verified
            )
            print(f"User {user.username} created successfully!")  # Debugging

            # Generate email verification link
            print("Generating email verification link")  # Debugging
            token = default_token_generator.make_token(user)
            print(f"Token generated: {token}")  # Debugging
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            print(f"Encoded UID: {uid}")  # Debugging
            current_site = get_current_site(request)
            mail_subject = 'Activate your account'
            message = render_to_string('Authy/activation_email.html', {
                'user': user,
                'domain': current_site.domain,
                'uid': uid,
                'token': token,
            })
            print(f"Generated email message: {message}")  # Debugging

            try:
                send_mail(mail_subject, message, 'testusersmtp4@gmail.com', [email])
                print("Email sent successfully!")  # Debugging
                messages.info(request, "Please check your email to verify your account.")
                return redirect('Authy:reg_successful')
            except Exception as e:
                print(f"Error sending email: {e}")  # Debugging
                messages.error(request, f"Error sending email: {e}")
                return redirect('Authy:registration')

        print("Form is not valid")  # Debugging
        print(form.errors.as_data())  # Debugging
        return render(request, 'Authy/register.html', {'form': form})

    print("GET request received, rendering empty form")  # Debugging
    form = CustomUserForms()
    return render(request, 'Authy/register.html', {'form': form})


def verify_email(request, uidb64, token):
    print("Email verification triggered")  # Debugging
    try:
        # Decode user ID
        uid = force_str(urlsafe_base64_decode(uidb64))
        print(f"Decoded UID: {uid}")  # Debugging
        user = CustomUser.objects.get(pk=uid)
        print(f"User found: {user.username}")  # Debugging

        # Check if the token is valid
        if default_token_generator.check_token(user, token):
            print(f"Token is valid")  # Debugging
            user.is_active = True  # Activate the user
            user.save()
            print(f"User {user.username} activated")  # Debugging

            # Instead of authenticating with the hashed password, redirect the user to the login page
            # or authenticate using the credentials submitted during registration (without reusing the hashed password).
            messages.success(request, 'Your email has been verified! Please log in.')
            return redirect('Authy:login_view')  # Redirect to the login page for them to log in.

        else:
            print("Invalid or expired verification token")  # Debugging
            messages.error(request, 'Invalid or expired verification link')
            return redirect('Authy:authentication_fail')  # Redirect back to registration if the link is invalid

    except Exception as e:
        print(f"Error during verification: {e}")  # Debugging
        messages.error(request, f'Error: {e}')
        return redirect('Authy:authentication_fail')  # Redirect back to registration



def success(request):
    print(f"Success view triggered for user: {request.user}")  # Debugging
    return render(request, 'Authy/success.html', {'user': request.user})
def reg_successful(request):
    print(f"reg_success view triggered for user: {request.user}")  # Debugging
    return render(request, 'Authy/registration_successful.html', {'user': request.user})
def authentication_fail(request):
    return render(request,'Authy/authentication_fail.html', {'user': request.user})
def login_view(request):
    print(" Login view triggered")  # Debugging

    if request.method == 'POST':
        print("POST request received")  # Debugging

        form = AuthenticationForm(request, data=request.POST)
        print(" Form initialized with POST data")  # Debugging

        if form.is_valid():
            print(" Form is valid")  # Debugging

            # Extract username and password
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')

            print(f" Extracted Username: {username}, Password: {password}")  # Debugging

            # Authenticate user
            user = authenticate(request, username=username, password=password)

            if user is not None:
                print(f"User authenticated: {user.username}")
                login(request, user)
                messages.success(request, 'You have logged in successfully!')
                return redirect('Authy:login_successful')  # Redirect to success page
            else:
                print(" Authentication failed: Incorrect credentials or user does not exist.")
                messages.error(request, ' Invalid username or password.')
        else:
            print("Form errors:", form.errors)  # Debugging: Check form validation errors
            messages.error(request, 'Invalid form submission.')

    else:
        form = AuthenticationForm()
        print(" GET request received, rendering login form.")  # Debugging

    return render(request, 'Authy/login_view.html', {'form': form})
def login_successful(request):
    return render(request,'Authy/login_successful.html')

