
from django.urls import path
from . import views  # Import views from the current app

app_name = 'Authy'
urlpatterns = [

    path('registration/', views.registration, name="registration"),
    path('success/', views.success, name="success"),
    path('reg_successful/', views.reg_successful, name="reg_successful"),
    path('verify_email/<uidb64>/<token>/', views.verify_email, name="verify_email"),
    path('authentication_fail/', views.authentication_fail, name="authentication_fail"),
    path('login_view/', views.login_view, name="login_view"),
    path('login_successful/', views.login_successful, name="login_successful"),





]
