from django import forms
from .models import CustomUser

class CustomUserForms(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, min_length=8)
    password_confirmation = forms.CharField(widget=forms.PasswordInput, min_length=8)

    class Meta:
        model = CustomUser
        fields = ['username', 'full_name', 'email', 'mobile']

    def clean(self):
        """Validate that password and password confirmation match."""
        cleaned_data = super(CustomUserForms, self).clean()  # Python 2.7 compatible super() syntax
        password = cleaned_data.get('password')
        password_confirmation = cleaned_data.get('password_confirmation')

        if password_confirmation and password != password_confirmation:
            raise forms.ValidationError("Passwords do not match.")

        return cleaned_data
