from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class CustomerUserManager(BaseUserManager):
    def create_user(self, username, email=None, mobile=None, password=None, **extra_fields):
        # Ensure that the username is provided
        if not username:
            raise ValueError("The username field must be set")

        # Normalize the email if provided
        email = self.normalize_email(email) if email else None
        # Create the user instance with the given fields
        user = self.model(username=username, email=email, mobile=mobile, **extra_fields)
        # Set the password (hashed) using set_password method
        user.set_password(password)
        user.save()  # Save the user to the database
        return user



class CustomUser(AbstractBaseUser):
    # Define custom fields for the user model
    username = models.CharField(max_length=50, unique=True)
    full_name = models.CharField(max_length=150)
    email = models.EmailField(unique=True, blank=True, null=True)
    mobile = models.CharField(max_length=15, unique=True, blank=True, null=True)
    is_active = models.BooleanField(default=False)

    # Link the custom manager to the model
    objects = CustomerUserManager()

    # Define the unique field for authentication (username here)
    USERNAME_FIELD = 'username'
    # Fields that will be used for creating a superuser
    REQUIRED_FIELDS = ['full_name']

    def __str__(self):
        # Return the username as the string representation of the user
        return self.username
